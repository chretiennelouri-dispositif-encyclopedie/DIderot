// Scroll horizontal infini — tranches verticales avec large dépassement.
// - Clonage avant/après pour illusion infinie
// - Conversion wheel vertical -> horizontal
// - Snap au plus proche encadré, correction quand on est sur un clone
// - Liens inline dans le texte (#sN / data-index) déclenchent scroll vers la copie centrale
// - Ajout des classes .active / .adjacent pour mise en avant visuelle

(function(){
  const container = document.getElementById('h-wrapper');
  let originalNodes = Array.from(container.querySelectorAll('.slot.original'));
  let originalCount = originalNodes.length;

  // Clone toutes les originales en préfixe et suffixe
  for (let i = originalCount - 1; i >= 0; i--) {
    const clone = originalNodes[i].cloneNode(true);
    clone.classList.add('clone');
    container.prepend(clone);
  }
  for (let i = 0; i < originalCount; i++) {
    const clone = originalNodes[i].cloneNode(true);
    clone.classList.add('clone');
    container.appendChild(clone);
  }

  // Liste complète après clonage (slots DOM)
  let slots = Array.from(container.querySelectorAll('.slot'));

  // calcule la distance horizontale (inclut gap) entre le début de 2 colonnes successives
  function computeSectionWidth(){
    if (slots.length < 2) return slots[0].getBoundingClientRect().width;
    const r0 = slots[0].getBoundingClientRect();
    let r1 = null;
    for (let i = 1; i < slots.length; i++) {
      const rect = slots[i].getBoundingClientRect();
      if (Math.abs(rect.left - r0.left) > 2) { r1 = rect; break; }
    }
    if (!r1) r1 = slots[1].getBoundingClientRect();
    return Math.abs(r1.left - r0.left);
  }

  let sectionWidth = computeSectionWidth();
  let currentIndex = originalCount; // index logique (on commence sur la première original centrale)

  // Positionnement initial sans animation
  container.scrollLeft = currentIndex * sectionWidth;
  updateActiveClasses();

  // Recalculer la largeur effective au redimensionnement
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    if (resizeTimer) clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      slots = Array.from(container.querySelectorAll('.slot'));
      sectionWidth = computeSectionWidth();
      container.style.scrollBehavior = 'auto';
      container.scrollLeft = currentIndex * sectionWidth;
      requestAnimationFrame(()=> container.style.scrollBehavior = 'smooth');
      updateActiveClasses();
    }, 90);
  });

  // Convertit wheel vertical -> horizontal (sauf si shift)
  container.addEventListener('wheel', (ev) => {
    if (ev.shiftKey) return;
    if (Math.abs(ev.deltaY) > Math.abs(ev.deltaX)) {
      ev.preventDefault();
      container.scrollBy({ left: ev.deltaY, behavior: 'auto' });
    }
  }, { passive: false });

  // Détection de fin de scroll (debounce) puis snap + correction clones
  let scrollTimeout = null;
  container.addEventListener('scroll', () => {
    if (scrollTimeout) clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(onScrollEnd, 120);
  });

  function onScrollEnd(){
    const idx = Math.round(container.scrollLeft / sectionWidth);
    currentIndex = idx;
    container.scrollTo({ left: currentIndex * sectionWidth, behavior: 'smooth' });

    // correction si on est dans les clones
    if (currentIndex >= originalCount * 2) {
      const mapped = currentIndex - originalCount;
      currentIndex = mapped;
      setTimeout(() => {
        container.style.scrollBehavior = 'auto';
        container.scrollLeft = currentIndex * sectionWidth;
        container.style.scrollBehavior = 'smooth';
        updateHashFromCurrent();
        updateActiveClasses();
      }, 70);
      return;
    }
    if (currentIndex < originalCount) {
      const mapped = currentIndex + originalCount;
      currentIndex = mapped;
      setTimeout(() => {
        container.style.scrollBehavior = 'auto';
        container.scrollLeft = currentIndex * sectionWidth;
        container.style.scrollBehavior = 'smooth';
        updateHashFromCurrent();
        updateActiveClasses();
      }, 70);
      return;
    }

    updateHashFromCurrent();
    updateActiveClasses();
  }

  // Gestion des clics sur liens <a> (data-index / hash) — liens dans le texte
  document.addEventListener('click', (ev) => {
    const a = ev.target.closest('a');
    if (!a) return;
    if (a.dataset.index !== undefined) {
      ev.preventDefault();
      const targetOriginal = parseInt(a.dataset.index, 10);
      if (Number.isNaN(targetOriginal) || targetOriginal < 0 || targetOriginal >= originalCount) return;
      const baseIndex = originalCount;
      currentIndex = baseIndex + targetOriginal;
      container.scrollTo({ left: currentIndex * sectionWidth, behavior: 'smooth' });
      history.replaceState(null, '', '#s' + targetOriginal);
      updateActiveClasses();
      return;
    }
    if (a.hash && /^#s\d+$/.test(a.hash)) {
      ev.preventDefault();
      const n = parseInt(a.hash.substring(2), 10);
      if (!Number.isNaN(n) && n >= 0 && n < originalCount) {
        const baseIndex = originalCount;
        currentIndex = baseIndex + n;
        container.scrollTo({ left: currentIndex * sectionWidth, behavior: 'smooth' });
        history.replaceState(null, '', a.hash);
        updateActiveClasses();
      }
      return;
    }
  });

  // Support chargement direct avec hash (#sN)
  if (location.hash && /^#s\d+$/.test(location.hash)) {
    const n = parseInt(location.hash.substring(2), 10);
    if (!Number.isNaN(n) && n >= 0 && n < originalCount) {
      currentIndex = originalCount + n;
      requestAnimationFrame(()=> {
        container.scrollLeft = currentIndex * sectionWidth;
        updateActiveClasses();
      });
    }
  }

  // Met à jour le hash (index original)
  function updateHashFromCurrent(){
    const originalIndex = ((currentIndex % originalCount) + originalCount) % originalCount;
    history.replaceState(null, '', '#s' + originalIndex);
  }

  // Met à jour classes "active" et "adjacent" (visuels)
  function updateActiveClasses(){
    slots.forEach(s => s.classList.remove('active','adjacent'));
    if (currentIndex < 0) currentIndex = 0;
    if (currentIndex >= slots.length) currentIndex = slots.length - 1;
    const active = slots[currentIndex];
    if (active) active.classList.add('active');
    const left = slots[currentIndex - 1];
    const right = slots[currentIndex + 1];
    if (left) left.classList.add('adjacent');
    if (right) right.classList.add('adjacent');
  }

})();